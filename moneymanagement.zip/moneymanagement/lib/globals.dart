library my_prj.globals;


int pageIndex = 0;
int amount = 0;
int resultprice = 0;
var cart = [];