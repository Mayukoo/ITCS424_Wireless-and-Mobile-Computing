
class title {
  static String appName = "Money Management";
  static String report = "Report";
  static String result = "Item in cart : 0";
  static String totalamount = "Total Amount";
}