import 'dart:ffi';

class MoneyModels{

  String type;
  double amount;
  String dateTime;

  MoneyModels({this.type,this.amount,this.dateTime});
}