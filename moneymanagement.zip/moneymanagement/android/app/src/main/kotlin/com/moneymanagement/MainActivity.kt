package com.moneymanagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
